﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCExample.Models
{
    public class User
    {
       public string name { get; set; }
       public string userID { get; set; }
    }
}