﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XMLForm
{
    public class User
    {
        public string email { set; get; }
        public string username { set; get; }
    }
}
